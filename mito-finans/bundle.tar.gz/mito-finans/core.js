/* MİTO Finans: pure financial calculation engine. No network, no dependencies. */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.MitoCore = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const DAY_MS = 86400000;
  const uid = () => typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : 'm_' + Date.now().toString(36) + Math.random().toString(36).slice(2);
  function parts(iso) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(iso || ''))) return null;
    const [y, m, d] = iso.split('-').map(Number);
    const date = new Date(Date.UTC(y, m - 1, d));
    if (date.getUTCFullYear() !== y || date.getUTCMonth() + 1 !== m || date.getUTCDate() !== d) return null;
    return {y, m, d};
  }
  const fmt = (y, m, d) => [y, String(m).padStart(2,'0'), String(d).padStart(2,'0')].join('-');
  function shiftDays(iso, n) { const p = parts(iso); if (!p) return ''; return new Date(Date.UTC(p.y,p.m-1,p.d+n)).toISOString().slice(0,10); }
  function addMonths(iso, n) {
    const p = parts(iso); if (!p || !Number.isInteger(n)) return '';
    const first = new Date(Date.UTC(p.y, p.m-1+n, 1));
    const last = new Date(Date.UTC(first.getUTCFullYear(),first.getUTCMonth()+1,0)).getUTCDate();
    return fmt(first.getUTCFullYear(),first.getUTCMonth()+1,Math.min(p.d,last));
  }
  function dueDayInMonth(year, month, day) {
    const last = new Date(Date.UTC(year,month,0)).getUTCDate();
    return fmt(year,month,Math.min(Math.max(Number(day)||1,1),last));
  }
  function shiftWeekend(iso) {
    const p = parts(iso); if (!p) return '';
    const weekday = new Date(Date.UTC(p.y,p.m-1,p.d)).getUTCDay();
    return weekday === 6 ? shiftDays(iso,2) : weekday === 0 ? shiftDays(iso,1) : iso;
  }
  function effectiveDate(item) { return item.weekendShift === false ? item.dueDate : shiftWeekend(item.dueDate); }
  function moneyToCents(input) {
    let s = String(input ?? '').trim().replace(/\s|₺|TL/gi,'');
    if (!s) return NaN;
    // 1.234,56 (TR), 1234.56, or integer. Ambiguous single separator with 3 decimals = grouping.
    if (s.includes(',') && s.includes('.')) s = s.replace(/\./g,'').replace(',','.');
    else if (s.includes(',')) s = s.replace(',','.');
    else if (/^\d{1,3}(?:\.\d{3})+$/.test(s)) s = s.replace(/\./g,'');
    if (!/^\d+(?:\.\d{1,2})?$/.test(s)) return NaN;
    const [whole,dec=''] = s.split('.');
    const cents = Number(whole) * 100 + Number(dec.padEnd(2,'0'));
    return Number.isSafeInteger(cents) ? cents : NaN;
  }
  function formatMoney(amount, currency='TRY') {
    return new Intl.NumberFormat('tr-TR',{style:'currency', currency, maximumFractionDigits:2}).format((Number(amount)||0)/100);
  }
  function monthKey(iso) { return String(iso || '').slice(0,7); }
  function planOccurrences(plan, from, to) {
    if (!parts(plan.firstDue)) return [];
    const total = plan.repeat === 'monthly_forever' ? 600 : Math.max(0,Math.min(1200,Number(plan.totalMonths)||0));
    const out=[];
    for(let i=0; i<total; i++) {
      const rawDate=addMonths(plan.firstDue,i-(Number(plan.paidBefore)||0));
      if (!rawDate) break;
      if (rawDate>shiftDays(to,3)) break;
      if (i < (Number(plan.paidBefore)||0)) continue;
      const date=plan.weekendShift===false ? rawDate : shiftWeekend(rawDate);
      if (date < from || date > to) continue;
      out.push({id:plan.id+':'+i,originId:plan.id,kind:plan.kind||'loan',label:plan.name,amount:plan.amount,minimum:0,dueDate:rawDate,displayDate:date,monthIndex:i+1,totalMonths:plan.repeat==='monthly_forever'?null:total,repeat:plan.repeat||'finite',planId:plan.id,weekendShift:plan.weekendShift !== false});
    }
    return out;
  }
  function paymentsFor(state, id) { return (state.payments||[]).filter(x=>x.targetId===id); }
  function paidCents(state, id) { return paymentsFor(state,id).reduce((n,p)=>n+(Number(p.amount)||0),0); }
  function remainingCents(state, item) { return Math.max(0,(Number(item.amount)||0)-paidCents(state,item.id)); }
  function completion(state,item) { const r=remainingCents(state,item);return r===0?'paid':r < (Number(item.amount)||0)?'partial':'open'; }
  function getOccurrences(state, from, to) {
    let out = (state.debts||[]).filter(o=>parts(o.dueDate)).map(o=>({id:o.id,originId:o.id,kind:o.kind||'other',label:o.name,amount:o.amount,minimum:o.minimum||0,accountId:o.accountId||'',dueDate:o.dueDate,displayDate:effectiveDate(o),note:o.note||'',weekendShift:o.weekendShift!==false})).filter(o=>o.displayDate>=from&&o.displayDate<=to);
    (state.plans||[]).forEach(p=>{out=out.concat(planOccurrences(p,from,to));});
    return out.map(o=>({...o,paid:paidCents(state,o.id),remaining:remainingCents(state,o),status:completion(state,o)})).sort((a,b)=>a.displayDate.localeCompare(b.displayDate)||a.label.localeCompare(b.label,'tr'));
  }
  function incomesForMonth(state, key) {
    const yr=Number(key.slice(0,4)),mo=Number(key.slice(5,7));
    return (state.incomes||[]).filter(x=>x.recurring ? !!parts(x.date)&&x.date.slice(0,7)<=key : monthKey(x.date)===key).map(x=>({...x,dueDate:x.recurring?dueDayInMonth(yr,mo,Number(x.date.slice(8))):x.date}));
  }
  function monthStats(state, key) {
    const start=key+'-01', p=parts(start); if(!p) return null;
    const next=addMonths(start,1),end=shiftDays(next,-1);
    const items=getOccurrences(state,start,end);
    const due=items.reduce((n,x)=>n+x.amount,0);
    const paid=items.reduce((n,x)=>n+x.paid,0);
    const incomes=incomesForMonth(state,key).reduce((n,x)=>n+(Number(x.amount)||0),0);
    return {items,due,paid,remaining:Math.max(0,due-paid),incomes,balance:incomes-Math.max(0,due-paid),count:items.filter(x=>x.remaining>0).length};
  }
  function outstandingAll(state, today, lookaheadMonths=24) {
    const p=parts(today); if(!p)return 0;
    // Include past dated unpaid invoices without dropping overdue debt.
    const past=(state.debts||[]).reduce((n,x)=>n+remainingCents(state,x),0);
    const planRemaining=(state.plans||[]).reduce((n,p)=>{
      const total=p.repeat==='monthly_forever'?0:Math.max(0,Number(p.totalMonths)||0);
      let sum=0;
      for(let i=Math.max(0,Number(p.paidBefore)||0);i<total;i++) sum+=Math.max(0,(Number(p.amount)||0)-paidCents(state,p.id+':'+i));
      return n+sum;
    },0);
    return past+planRemaining;
  }
  function countsForPlan(state,plan) {
    if (plan.repeat==='monthly_forever') return null;
    let left=0;
    for(let i=Math.max(0,Number(plan.paidBefore)||0);i<Number(plan.totalMonths||0);i++) if(Math.max(0,plan.amount-paidCents(state,plan.id+':'+i))>0)left++;
    return left;
  }
  function validateState(s) {
    if (!s || typeof s!=='object'||Array.isArray(s))throw Error('Geçersiz yedek.');
    for(const k of ['accounts','debts','plans','payments','incomes'])if(!Array.isArray(s[k])||s[k].length>10000)throw Error('Yedekte '+k+' alanı eksik veya çok büyük.');
    const ids=[];
    for(const collection of ['accounts','debts','plans','payments','incomes'])for(const o of s[collection]){
      if(!o || typeof o.id!=='string'||o.id.length>120)throw Error('Bozuk kayıt kimliği.');
      if(collection!=='payments' && collection!=='accounts' && collection!=='incomes' && (!Number.isSafeInteger(o.amount)||o.amount<0||o.amount>1e14))throw Error('Geçersiz tutar.');
      if(['payments','incomes'].includes(collection) && (!Number.isSafeInteger(o.amount)||o.amount<0||o.amount>1e14))throw Error('Geçersiz işlem.');
      ids.push(o.id+'#'+collection);
    }
    if(new Set(ids).size!==ids.length)throw Error('Yinelenen kayıt kimliği.');
    return {...s,version:1,settings:{weekendShift:true,notify:true,...(s.settings||{})}};
  }
  function initialState() {return {version:1,accounts:[],debts:[],plans:[],payments:[],incomes:[],settings:{weekendShift:true,notify:true}};}
  return {uid,parts,fmt,shiftDays,addMonths,dueDayInMonth,shiftWeekend,effectiveDate,moneyToCents,formatMoney,monthKey,planOccurrences,paymentsFor,paidCents,remainingCents,completion,getOccurrences,incomesForMonth,monthStats,outstandingAll,countsForPlan,validateState,initialState};
});
