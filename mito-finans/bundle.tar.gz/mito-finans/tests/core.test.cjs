const test = require('node:test');
const assert = require('node:assert/strict');
const C = require('../core.js');
const state=()=>C.initialState();
test('Turkish weekend due dates move Sat->Mon and Sun->Mon, including month and year',()=>{
 assert.equal(C.shiftWeekend('2026-10-17'),'2026-10-19');
 assert.equal(C.shiftWeekend('2026-10-18'),'2026-10-19');
 assert.equal(C.shiftWeekend('2026-10-19'),'2026-10-19');
 assert.equal(C.shiftWeekend('2026-01-31'),'2026-02-02');
 assert.equal(C.shiftWeekend('2027-01-02'),'2027-01-04');
});
test('monthly payments clamp short months and leap years',()=>{
 assert.equal(C.addMonths('2026-01-31',1),'2026-02-28');
 assert.equal(C.addMonths('2028-01-31',1),'2028-02-29');
 assert.equal(C.addMonths('2026-12-31',1),'2027-01-31');
 assert.equal(C.dueDayInMonth(2026,2,31),'2026-02-28');
 assert.equal(C.parts('2026-02-29'),null);
});
test('Turkish money parsing is exact integer cents',()=>{
 assert.equal(C.moneyToCents('1.234,56'),123456);
 assert.equal(C.moneyToCents('1234.56'),123456);
 assert.equal(C.moneyToCents('1.234'),123400);
 assert.equal(C.moneyToCents('2,5'),250);
 assert.equal(C.moneyToCents('bad'),NaN);
 assert.equal(C.moneyToCents('15,001'),NaN);
});
test('statement partial and complete payments reconcile',()=>{
 const s=state();s.debts.push({id:'b1',name:'Ekstre',kind:'statement',amount:100_000,dueDate:'2026-10-18',weekendShift:true,minimum:20_000});
 s.payments.push({id:'p1',targetId:'b1',amount:20_000,date:'2026-10-18'});
 assert.equal(C.paidCents(s,'b1'),20_000);
 assert.equal(C.remainingCents(s,s.debts[0]),80_000);
 assert.equal(C.completion(s,s.debts[0]),'partial');
 s.payments.push({id:'p2',targetId:'b1',amount:80_000,date:'2026-10-19'});
 assert.equal(C.remainingCents(s,s.debts[0]),0);
 assert.equal(C.completion(s,s.debts[0]),'paid');
 s.payments.pop();assert.equal(C.remainingCents(s,s.debts[0]),80_000);
});
test('loan remaining years with already paid months and one new payment',()=>{
 const s=state();s.plans.push({id:'l1',name:'İhtiyaç kredisi',amount:12_500,totalMonths:36,paidBefore:12,firstDue:'2026-10-31',kind:'loan',repeat:'finite',weekendShift:true});
 let all=C.getOccurrences(s,'2026-10-01','2026-12-31');
 assert.equal(all.length,3);
 assert.equal(all[0].id,'l1:12');assert.equal(all[0].dueDate,'2026-10-31');assert.equal(all[0].displayDate,'2026-11-02');
 assert.equal(all[0].monthIndex,13);
 assert.equal(C.countsForPlan(s,s.plans[0]),24);
 s.payments.push({id:'p',targetId:'l1:12',amount:12_500,date:'2026-11-02'});
 assert.equal(C.countsForPlan(s,s.plans[0]),23);
 assert.equal(C.outstandingAll(s,'2026-10-18'),23*12_500);
});
test('monthly summary uses shifted month and excludes card duplicate',()=>{
 const s=state();s.accounts.push({id:'c',name:'Bank',bank:'Bank'});
 s.debts.push({id:'st',kind:'statement',name:'Ekstre',accountId:'c',amount:20000,dueDate:'2026-10-31',weekendShift:true});
 assert.equal(C.monthStats(s,'2026-10').due,0);
 assert.equal(C.monthStats(s,'2026-11').due,20000);
 assert.equal(C.outstandingAll(s,'2026-10-18'),20000);
});
test('recurring salaries start on specified month and align month end',()=>{
 const s=state();s.incomes.push({id:'i',name:'Salary',amount:120000,date:'2026-01-31',recurring:true});
 assert.equal(C.incomesForMonth(s,'2025-12').length,0);
 assert.equal(C.incomesForMonth(s,'2026-02')[0].dueDate,'2026-02-28');
 assert.equal(C.monthStats(s,'2026-02').incomes,120000);
});
test('malformed backups are rejected',()=>{
 assert.throws(()=>C.validateState({accounts:[],debts:[]}),/eksik/);
 const s=state();s.debts.push({id:'x',amount:-1,dueDate:'2026-10-19'});
 assert.throws(()=>C.validateState(s),/tutar/);
});
