package com.mito.finans;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

public class AlarmReceiver extends BroadcastReceiver {
    private static final String CHANNEL="mito_due_v1";
    @Override public void onReceive(Context context, Intent intent) {
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm==null)return;
        if(Build.VERSION.SDK_INT>=33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
        if(Build.VERSION.SDK_INT>=26){NotificationChannel channel=new NotificationChannel(CHANNEL,"Ödeme hatırlatmaları",NotificationManager.IMPORTANCE_DEFAULT);channel.setDescription("Kredi kartı, kredi ve taksit son ödeme uyarıları");nm.createNotificationChannel(channel);}
        Intent launch=new Intent(context,MainActivity.class);
        launch.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent open=PendingIntent.getActivity(context,0,launch,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        String key=intent.getStringExtra("key");
        String title=intent.getStringExtra("title");String body=intent.getStringExtra("body");
        Notification.Builder nb=Build.VERSION.SDK_INT>=26?new Notification.Builder(context,CHANNEL):new Notification.Builder(context);
        Notification note=nb.setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle(title==null?"MİTO Finans":title).setContentText(body==null?"Bir ödeme yaklaşıyor.":body).setAutoCancel(true).setContentIntent(open).setVisibility(Notification.VISIBILITY_PRIVATE).build();
        nm.notify(key==null?0:key.hashCode(),note);
    }
}
