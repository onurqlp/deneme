package com.mito.finans;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.HashSet;
import java.util.Set;

public final class ReminderScheduler {
    private static final String PREF="mito_notifications";
    private static final String IDS="previous_keys";
    private static final String JSON="raw_schedule";
    private ReminderScheduler(){}
    static void update(Context c,String data) {
        try {
            new JSONArray(data); // Only store well-formed data, never accept arbitrary intents.
            c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString(JSON,data).apply();
            schedule(c,data);
        } catch(Exception ignored) {}
    }
    static void restore(Context c) {
        SharedPreferences p=c.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        schedule(c,p.getString(JSON,"[]"));
    }
    private static PendingIntent intent(Context c,String key,String title,String body) {
        Intent i=new Intent(c,AlarmReceiver.class);
        i.setAction("com.mito.finans.REMINDER");
        i.putExtra("title",title);
        i.putExtra("body",body);
        i.putExtra("key",key);
        return PendingIntent.getBroadcast(c,key.hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private static void schedule(Context c,String raw) {
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(am==null)return;
        SharedPreferences prefs=c.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        for(String key:prefs.getStringSet(IDS,new HashSet<>())) {
            PendingIntent old=intent(c,key,"","");
            am.cancel(old);
            old.cancel();
        }
        Set<String> next=new HashSet<>();
        try {
            JSONArray arr=new JSONArray(raw);
            for(int x=0;x<Math.min(200,arr.length());x++) {
                JSONObject obj=arr.getJSONObject(x);
                String key=obj.optString("key","");
                String date=obj.optString("day","");
                if(key.length()<1||key.length()>160)continue;
                long time=LocalDate.parse(date).atTime(LocalTime.of(9,0)).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
                if(time<System.currentTimeMillis())continue;
                PendingIntent intent=intent(c,key,obj.optString("title","Ödeme hatırlatması"),obj.optString("body",""));
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,time,intent);
                next.add(key);
            }
        } catch(Exception ignored) {}
        prefs.edit().putStringSet(IDS,next).apply();
    }
}
