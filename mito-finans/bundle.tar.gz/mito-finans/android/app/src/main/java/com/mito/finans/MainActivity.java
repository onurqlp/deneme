package com.mito.finans;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.net.Uri;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    private String pendingBackup;
    private static final int CREATE_BACKUP = 501;
    private static final int OPEN_BACKUP = 502;
    private static final String HOME = "file:///android_asset/index.html";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(16,31,53));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(255,255,255));
        getWindow().getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(245,247,248));
        WebSettings config = webView.getSettings();
        config.setJavaScriptEnabled(true);
        config.setDomStorageEnabled(true);
        config.setAllowFileAccess(true); // HTML, CSS and JavaScript bundled inside APK
        config.setAllowContentAccess(false);
        config.setAllowFileAccessFromFileURLs(false);
        config.setAllowUniversalAccessFromFileURLs(false);
        config.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        config.setJavaScriptCanOpenWindowsAutomatically(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !HOME.equals(request.getUrl().toString());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !HOME.equals(url);
            }
        });
        webView.addJavascriptInterface(new LocalBridge(), "Android");
        setContentView(webView);
        webView.loadUrl(HOME);
    }

    public final class LocalBridge {
        @JavascriptInterface public void scheduleReminders(String json) {
            ReminderScheduler.update(MainActivity.this,json);
        }
        @JavascriptInterface public void requestNotificationPermission() {
            runOnUiThread(() -> {
                if(Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != getPackageManager().PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},700);
                }
            });
        }
        @JavascriptInterface public void exportBackup(String json) {
            if(json == null || json.length() > 5_000_000) return;
            runOnUiThread(() -> {
                pendingBackup = json;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE,"mito-finans-yedek-"+LocalDate.now()+".json");
                startActivityForResult(intent,CREATE_BACKUP);
            });
        }
        @JavascriptInterface public void importBackup() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                startActivityForResult(intent,OPEN_BACKUP);
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode != RESULT_OK || data == null || data.getData() == null)return;
        Uri uri = data.getData();
        try {
            if(requestCode == CREATE_BACKUP && pendingBackup != null) {
                try (OutputStream out=getContentResolver().openOutputStream(uri)) {
                    if(out != null)out.write(pendingBackup.getBytes(StandardCharsets.UTF_8));
                }
                pendingBackup=null;
            } else if(requestCode == OPEN_BACKUP) {
                try (InputStream in=getContentResolver().openInputStream(uri)) {
                    if(in == null)return;
                    byte[] bytes=in.readNBytes(5_000_001);
                    if(bytes.length>5_000_000){webView.evaluateJavascript("window.mitoNativeError('Yedek 5 MB sınırını aşıyor.')",null);return;}
                    String contents = new String(bytes,StandardCharsets.UTF_8);
                    webView.evaluateJavascript("window.mitoNativeImport("+JSONObject.quote(contents)+")",null);
                }
            }
        } catch(Exception e) {
            webView.evaluateJavascript("window.mitoNativeError('Dosya okunamadı veya yazılamadı.')",null);
        }
    }
    @Override public void onBackPressed() {
        webView.evaluateJavascript("(function(){var d=document.querySelector('dialog[open]');if(d){d.close();return true;}return false;})()",value -> {if(!"true".equals(value))super.onBackPressed();});
    }
    @Override protected void onDestroy() {
        if(webView!=null){webView.removeJavascriptInterface("Android");webView.destroy();}
        super.onDestroy();
    }
}
