# MİTO Finans — Offline Android APK & web preview

Kredi kartı ekstreleri, kısmi ödemeler, kredi/okul taksit planları, tekil giderler ve tahmini gelirleri sunucusuz takip eder. Tüm kayıtlar cihazdaki WebView/tarayıcı yerel deposundadır. Web arayüzü: `index.html` (geliştirmede localhost üzerinden servis edilmeli).

## Android APK

Projeyi `mito-finans/` klasörü olarak test deposunun köküne, iş akışını ise depo kökündeki `.github/workflows/mito-finans-apk.yml` yoluna koyun. GitHub Actions **MİTO Finans APK** iş akışında build sonrası `mito-finans-debug-apk` artefaktından APK indirilebilir. Proje harici çalışma zamanı API'si veya internet izni istemez. Otomatik hatırlatmalar cihaz saatine göre vade gününde ve 1/3/7 gün önce sabah 09.00'da planlanır; Android pil optimizasyonu nedeniyle dakika kesinliği garantilenmez.

## Yerel çalıştırma ve test

```bash
node --test tests/core.test.cjs
python3 -m http.server 8000
```

Sonra `http://localhost:8000/` adresini açın. Android için JDK 17, Android SDK 35 ve Gradle 8.9 gerekir: `cd android && gradle :app:assembleDebug`. GitHub Actions bulutta APK üretir; kendi sunucusu gerekmez.

## Veri güvenliği ve sınırlar

- Tutarlar küsurat kaybını önlemek için kuruş cinsinden tam sayı tutulur.
- Kısmi ödemeler hareket olarak saklanır; kalan tutar buradan hesaplanır. Önceden ödenmiş kredi ayları başlangıç sayacından düşülür.
- Hafta sonuna gelen vadeler ileri ilk pazartesiye ötelenir (özgün vade korunur). Resmî tatil takvimi ve bankaya özel kurallar **dahil değildir**; gerçek son ödeme tarihi için banka bilgisi belirleyicidir.
- Web sürümü tarayıcıya, Android sürümü APK'nın cihazdaki WebView deposuna kaydeder. Birbirleri otomatik eşitlenmez. Yedeği JSON olarak dışa aktar / geri yükle. Yedek **şifresizdir**.
- Kullanıcı tarafından girilen borçlar bankayla otomatik doğrulanmaz. Bir bankanın normal kredi kartı ekstresi yalnızca bir kere eklendiğinde çift sayılmaz.
- Yeni veri girişi yapılmadan bildirim güncellenmeyebilir; bildirimleri OS kapatabilir.
- Telefon/app verisi silindiğinde veya kaldırıldığında yedeksiz kayıtlar geri gelmez.
- Bu çalışma v1 ilk sürümdür. Banka entegrasyonu, resmî tatil takvimi, şifreli depolama, PIN/biyometri, çoklu cihaz senkronizasyonu ve Play Store imzalı sürüm ileride değerlendirilebilir.

## Kalite kontrol

`tests/core.test.cjs`: hafta sonu, ay ve yıl taşması, şubat sonu, kuruş hesabı, kısmi/tam ödeme, kalan kredi taksiti, sonraki aya kayan ekstre, tekrar eden gelir ve bozuk yedekler için otomatik testler.
